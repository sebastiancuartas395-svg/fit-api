using FitApi.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FitApi.Data;
using FitApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FitApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RutinasController : ControllerBase
    {
        private readonly FitApiContext _context;

        public RutinasController(FitApiContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Rutina>>> Get() =>
            Ok(await _context.Rutinas.Include(r => r.Usuario).ToListAsync());

        [HttpGet("resumen")]
        public async Task<ActionResult<IEnumerable<TotalObjetivosUsuarioVM>>> Resumen()
        {
            var resumen = await _context.Set<TotalObjetivosUsuarioVM>().FromSqlRaw(@"
                SELECT u.Nombre AS Usuario, o.Nombre AS Objetivo, COUNT(*) AS VecesAsignado
                FROM DetallesRutina dr
                JOIN Rutinas r ON dr.RutinaId = r.Id
                JOIN Usuarios u ON r.UsuarioId = u.Id
                JOIN Objetivos o ON dr.ObjetivoId = o.Id
                GROUP BY u.Nombre, o.Nombre
            ").ToListAsync();

            return Ok(resumen);
        }

        [HttpPost]
        public async Task<ActionResult<Rutina>> Post(RutinaDTO dto)
        {
            var rutina = new Rutina { UsuarioId = dto.UsuarioId };
            _context.Rutinas.Add(rutina);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = rutina.Id }, rutina);
        }
    }
}
