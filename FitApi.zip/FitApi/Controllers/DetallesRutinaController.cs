using FitApi.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FitApi.Data;
using FitApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FitApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DetallesRutinaController : ControllerBase
    {
        private readonly FitApiContext _context;

        public DetallesRutinaController(FitApiContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<DetalleRutina>>> Get() =>
            Ok(await _context.DetallesRutina
                .Include(d => d.Rutina)
                .Include(d => d.Objetivo)
                .ToListAsync());

        [HttpPost]
        public async Task<ActionResult<DetalleRutina>> Post(DetalleRutinaDTO dto)
        {
            var detalle = new DetalleRutina
            {
                RutinaId = dto.RutinaId,
                ObjetivoId = dto.ObjetivoId,
                Repeticiones = dto.Repeticiones,
                Series = dto.Series
            };
            _context.DetallesRutina.Add(detalle);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = detalle.Id }, detalle);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, DetalleRutinaDTO dto)
        {
            var detalle = await _context.DetallesRutina.FindAsync(id);
            if (detalle == null) return NotFound();

            detalle.RutinaId = dto.RutinaId;
            detalle.ObjetivoId = dto.ObjetivoId;
            detalle.Repeticiones = dto.Repeticiones;
            detalle.Series = dto.Series;

            await _context.SaveChangesAsync();
            return Ok(detalle);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var detalle = await _context.DetallesRutina.FindAsync(id);
            if (detalle == null) return NotFound();

            _context.DetallesRutina.Remove(detalle);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
