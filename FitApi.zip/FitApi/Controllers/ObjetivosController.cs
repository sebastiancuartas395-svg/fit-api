using FitApi.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FitApi.Data;
using FitApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FitApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ObjetivosController : ControllerBase
    {
        private readonly FitApiContext _context;

        public ObjetivosController(FitApiContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Objetivo>>> Get() =>
            Ok(await _context.Objetivos.ToListAsync());

        [HttpPost]
        public async Task<ActionResult<Objetivo>> Post(ObjetivoDTO dto)
        {
            var objetivo = new Objetivo
            {
                Nombre = dto.Nombre,
                Descripcion = dto.Descripcion
            };
            _context.Objetivos.Add(objetivo);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = objetivo.Id }, objetivo);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, ObjetivoDTO dto)
        {
            var objetivo = await _context.Objetivos.FindAsync(id);
            if (objetivo == null) return NotFound();

            objetivo.Nombre = dto.Nombre;
            objetivo.Descripcion = dto.Descripcion;
            await _context.SaveChangesAsync();
            return Ok(objetivo);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var objetivo = await _context.Objetivos.FindAsync(id);
            if (objetivo == null) return NotFound();

            _context.Objetivos.Remove(objetivo);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
