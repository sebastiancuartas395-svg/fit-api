-- Crear la base de datos
CREATE DATABASE FitAppDb;
GO

-- Usar la base de datos
USE FitAppDb;
GO

-- Crear tabla Usuarios
CREATE TABLE Usuarios (
    Id INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100)
);
GO

-- Crear tabla Objetivos
CREATE TABLE Objetivos (
    Id INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Descripcion NVARCHAR(255)
);
GO

-- Crear tabla Rutinas
CREATE TABLE Rutinas (
    Id INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    UsuarioId INT FOREIGN KEY REFERENCES Usuarios(Id)
);
GO

-- Crear tabla DetallesRutina
CREATE TABLE DetallesRutina (
    Id INT PRIMARY KEY IDENTITY,
    RutinaId INT FOREIGN KEY REFERENCES Rutinas(Id),
    ObjetivoId INT FOREIGN KEY REFERENCES Objetivos(Id),
    Repeticiones INT
);
GO


--Insertar datos 
-- Usuarios
INSERT INTO Usuarios (Nombre) VALUES ('Ana');
INSERT INTO Usuarios (Nombre) VALUES ('Carlos');
INSERT INTO Usuarios (Nombre) VALUES ('Luisa');

-- Objetivos
INSERT INTO Objetivos (Nombre, Descripcion) VALUES ('Cardio', 'Ejercicios aeróbicos para resistencia');
INSERT INTO Objetivos (Nombre, Descripcion) VALUES ('Fuerza', 'Entrenamiento con pesas');
INSERT INTO Objetivos (Nombre, Descripcion) VALUES ('Flexibilidad', 'Estiramientos y movilidad');

-- Rutinas
INSERT INTO Rutinas (Nombre, UsuarioId) VALUES ('Rutina Ana 1', 1);
INSERT INTO Rutinas (Nombre, UsuarioId) VALUES ('Rutina Carlos 1', 2);
INSERT INTO Rutinas (Nombre, UsuarioId) VALUES ('Rutina Luisa 1', 3);

-- DetallesRutina
INSERT INTO DetallesRutina (RutinaId, ObjetivoId, Repeticiones) VALUES (1, 1, 30);
INSERT INTO DetallesRutina (RutinaId, ObjetivoId, Repeticiones) VALUES (1, 2, 15);
INSERT INTO DetallesRutina (RutinaId, ObjetivoId, Repeticiones) VALUES (2, 2, 20);
INSERT INTO DetallesRutina (RutinaId, ObjetivoId, Repeticiones) VALUES (3, 3, 25);
INSERT INTO DetallesRutina (RutinaId, ObjetivoId, Repeticiones) VALUES (3, 1, 10);