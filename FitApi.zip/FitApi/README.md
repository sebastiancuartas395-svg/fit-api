# FitApi

API REST para gestión de rutinas y objetivos de usuarios en un sistema fitness.

## 🛠️ Tecnologías

- ASP.NET Core
- Entity Framework Core
- SQL Server
- Swagger (OpenAPI)

## 📦 Estructura del modelo

- `Usuario`: representa al usuario del sistema
- `Objetivo`: metas o ejercicios definidos
- `Rutina`: conjunto de objetivos asignados a un usuario
- `DetalleRutina`: relación entre rutina y objetivos
- `TotalObjetivosUsuarioVM`: vista para resumen de objetivos por usuario

## 📡 Endpoints disponibles

### Usuarios

- `GET /api/usuarios` — Obtener todos los usuarios
- `POST /api/usuarios` — Crear nuevo usuario
- `PUT /api/usuarios/{id}` — Actualizar usuario existente
- `DELETE /api/usuarios/{id}` — Eliminar usuario

### Objetivos

- `GET /api/objetivos` — Obtener todos los objetivos
- `POST /api/objetivos` — Crear nuevo objetivo
- `PUT /api/objetivos/{id}` — Actualizar objetivo existente
- `DELETE /api/objetivos/{id}` — Eliminar objetivo

### Rutinas

- `GET /api/rutinas` — Obtener todas las rutinas (incluye usuario)
- `GET /api/rutinas/resumen` — Vista agregada de objetivos por usuario

### DetallesRutina

- `GET /api/detallesrutina` — Obtener todos los detalles de rutina
- `POST /api/detallesrutina` — Crear nuevo detalle
- `PUT /api/detallesrutina/{id}` — Actualizar detalle existente
- `DELETE /api/detallesrutina/{id}` — Eliminar detalle

## ⚙️ Configuración del proyecto

1. Clonar el repositorio:

   ```bash
   git clone https://github.com/tuusuario/FitApi.git
   cd FitApi
