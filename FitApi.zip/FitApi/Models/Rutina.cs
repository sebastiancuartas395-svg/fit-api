using System.ComponentModel.DataAnnotations;

public class Rutina
{
    public int Id { get; set; }

    [Required]
    public int UsuarioId { get; set; }

    public Usuario Usuario { get; set; }
}
