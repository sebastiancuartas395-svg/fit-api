namespace FitApi.Models
{
    public class TotalObjetivosUsuarioVM
    {
        public string Usuario { get; set; } = string.Empty;
        public string Objetivo { get; set; } = string.Empty;
        public int VecesAsignado { get; set; }
    }
}
