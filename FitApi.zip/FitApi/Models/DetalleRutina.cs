using System.ComponentModel.DataAnnotations;

public class DetalleRutina
{
    public int Id { get; set; }

    [Required]
    public int RutinaId { get; set; }

    [Required]
    public int ObjetivoId { get; set; }

    [Required]
    public int Repeticiones { get; set; }

    [Required]
    public int Series { get; set; }

    public Rutina Rutina { get; set; }
    public Objetivo Objetivo { get; set; }
}
