using System.ComponentModel.DataAnnotations;

namespace FitApi.DTOs
{
    public class ObjetivoDTO
    {
        [Required]
        public string Nombre { get; set; }

        [Required]
        public string Descripcion { get; set; }
    }
}
