using System.ComponentModel.DataAnnotations;

namespace FitApi.DTOs
{
    public class DetalleRutinaDTO
    {
        [Required]
        public int RutinaId { get; set; }

        [Required]
        public int ObjetivoId { get; set; }

        [Required]
        public int Repeticiones { get; set; }

        [Required]
        public int Series { get; set; }
    }
}
