using System.ComponentModel.DataAnnotations;

namespace FitApi.DTOs
{
    public class RutinaDTO
    {
        [Required]
        public int UsuarioId { get; set; }
    }
}
