using System.ComponentModel.DataAnnotations;

namespace FitApi.DTOs
{
    public class UsuarioDTO
    {
        [Required]
        public string Nombre { get; set; }
    }
}
