using Microsoft.EntityFrameworkCore;
using FitApi.Models;

namespace FitApi.Data
{
    public class FitApiContext : DbContext
    {
        public FitApiContext(DbContextOptions<FitApiContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Objetivo> Objetivos { get; set; }
        public DbSet<Rutina> Rutinas { get; set; }
        public DbSet<DetalleRutina> DetallesRutina { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TotalObjetivosUsuarioVM>().HasNoKey();
        }
    }
}
